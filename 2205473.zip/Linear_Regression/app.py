import streamlit as st
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

st.title('Linear Regression Web App')

# Upload Data
uploaded_file = st.file_uploader("Upload CSV", type=['csv'])
if uploaded_file:
    data = pd.read_csv(uploaded_file)
    st.write("Data Preview:", data.head())

    # Select features and target
    features = st.multiselect("Select Features", data.columns)
    target = st.selectbox("Select Target", data.columns)

    if features and target:
        X = data[features]
        y = data[target]

        # Train model
        model = LinearRegression()
        model.fit(X, y)

        # Predictions
        y_pred = model.predict(X)
        st.write("Predictions:", y_pred)

        # Plot Results
        plt.scatter(y, y_pred)
        plt.xlabel('Actual')
        plt.ylabel('Predicted')
        st.pyplot(plt)
